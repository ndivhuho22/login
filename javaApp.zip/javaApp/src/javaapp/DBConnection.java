/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

import com.mysql.jdbc.Connection;
import static java.lang.Character.UnicodeBlock.forName;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Mphelo N Ndivhuho
 */
public class DBConnection {
    private Connection DBConnection;
    public Connection connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("connection success");
        }
        
        catch (ClassNotFoundException cnfe){
            System.out.println("connection fail" + cnfe);
        }
        String url = "jdbc:mysql://localhost:3306/javaapp";
            try {
                DBConnection = (Connection) DriverManager.getConnection(url,"root","1234");
                 System.out.println("database connected");
            }
            
            catch (SQLException se){
                System.out.println("No database" + se);
            }
        return DBConnection;
    }

    private void forname(String commysqljdbcDriver) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
